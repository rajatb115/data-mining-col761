#!/bin/bash

# module load compiler/gcc/7.1.0/compilervars

# module load compiler/gcc/7.1.0/compilervars
# module load compiler/intel/2019u5/intelpython3
# module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
# module load pythonpackages/3.6.0/scipy/1.1.0/gnu
# module load compiler/intel/2019u5/intelpython3
# module load pythonpackages/3.6.0/numpy/1.16.1/gnu


g++ -o Q1/FSG/script_fsg Q1/FSG/script_fsg.cpp
g++ -o Q1/Gaston/script_gaston Q1/Gaston/script_gaston.cpp
g++ -o Q1/gSpan/script_gspan Q1/gSpan/script_gspan.cpp
