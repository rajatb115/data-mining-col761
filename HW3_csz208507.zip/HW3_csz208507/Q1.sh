#!/bin/bash

python3 Q1/Q1.py Q1/data.txt
