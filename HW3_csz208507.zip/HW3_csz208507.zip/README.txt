# Data Mining (COL761) - Homework 3

# Contributers

Rajat Singh - 2020CSZ8507
Chhavi Agarwal - 2020CSY7654
Shreyans J Nagori - 2018CS10390

# Part 1

To run the code use : python3 Q1.py filename
